package com.ayatec.shagf_console

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
